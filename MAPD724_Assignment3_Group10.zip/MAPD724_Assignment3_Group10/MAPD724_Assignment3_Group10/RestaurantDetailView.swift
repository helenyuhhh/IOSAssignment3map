//
//  RestaurantDetailView.swift
//  MAPD724_Assignment3_Group10
//
//  Created by Nirmala Thapa on 2025-03-13.
//

import SwiftUI
import Foundation
import CoreLocation

struct RestaurantDetailView: View {
    let restaurant: Restaurant
    let userLocation: CLLocation?

    var distanceText: String {
        guard let userLocation = userLocation else {
            return "Distance: Unknown"
        }
        
        let restaurantLocation = CLLocation(latitude: restaurant.latitude, longitude: restaurant.longitude)
        
        print("User Location: \(userLocation.coordinate.latitude), \(userLocation.coordinate.longitude)")
        print("Restaurant Location: \(restaurantLocation.coordinate.latitude), \(restaurantLocation.coordinate.longitude)")

        
        let distanceInMeters = userLocation.distance(from: restaurantLocation)
        let distanceInKilometers = distanceInMeters / 1000.0
        
        print("Distance to \(restaurant.name): \(distanceInKilometers) km")
        
        return String(format: "Distance: %.2f km", distanceInKilometers)
    }

    var body: some View {
        VStack {
            Text(restaurant.name)
                .font(.headline)
                .padding(.top)

            Text("Type: \(restaurant.typeOfFood)")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            Divider()
            
            //  Show Distance to Restaurant
            Text(distanceText)
                .font(.title3)
                .fontWeight(.medium)
                .padding(.top, 5)

            HStack {
                Image(systemName: "globe.desk")
                Text("Lat: \(restaurant.latitude, specifier: "%.4f"), Lon: \(restaurant.longitude, specifier: "%.4f")")
                    .font(.caption)
            }
            .padding(.bottom)
        }
        .frame(maxWidth: .infinity)
        .presentationDetents([.fraction(0.25)]) // Keep it 25% height
        .interactiveDismissDisabled(false) //  Allow user to dismiss manually
        .presentationBackgroundInteraction(.enabled) //  Keep map interactive
    }
}
