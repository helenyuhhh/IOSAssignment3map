//
//  LoationManager.swift
//  MAPD724_Assignment3_Group10
//
//  Created by Nirmala Thapa on 2025-03-13.
//

import Foundation
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    private var locationManager = CLLocationManager()
    
    @Published var userLocation: CLLocation? = nil
    
    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let latestLocation = locations.last else { return }
        print("User's location: \(latestLocation.coordinate.latitude), \(latestLocation.coordinate.longitude)")
        DispatchQueue.main.async {
            self.userLocation = latestLocation
        }
    }
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
           print("Failed to get user location: \(error.localizedDescription)")
       }
}
