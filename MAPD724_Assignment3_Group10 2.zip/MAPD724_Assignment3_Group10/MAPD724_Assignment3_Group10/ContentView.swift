//
//  ContentView.swift
//  MAPD724_Assignment3_Group10
//  Nirmala Thapa
//  Qianhui Yu
//
//  Created by Windy on 2025-03-11.
//

import SwiftUI
import MapKit

struct Restaurant: Identifiable, Hashable {
    let id = UUID()
    
    // NOTE:
    // Rather than this:
    // let coordinates: CLLocationCoordinate2D
    
    // Instead split into latitude and longitude as Double or CLLocationDegree
    // (same thing, typealias CLLocationDegrees == Double)
    
    // CLLocationCoordinate2D is not Equatable, Hashable or Codable
    // Double is all those things
    
    let latitude: Double
    let longitude: Double
    let name: String
    let typeOfFood: String
    
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}
// bakeries
class RestaurantModel: ObservableObject {
    //bakeries
    let bakeries = [
        Restaurant(latitude: 43.7856, longitude: -79.4145, name: "VaVa Designer Cake", typeOfFood: "Bakery"),
        Restaurant(latitude: 43.6466, longitude: -79.3925, name: "French Made Toronto", typeOfFood: "Bakery"),
        Restaurant(latitude: 43.6809, longitude: -79.4501, name: "Tre Mari Bakery", typeOfFood: "Bakery"),
        Restaurant(latitude: 43.6901, longitude: -79.3745, name: "Dolce Bakery", typeOfFood: "Bakery"),
        Restaurant(latitude: 43.8363, longitude: -79.2215, name: "Petit Delights", typeOfFood: "Bakery"),
        Restaurant(latitude: 43.7755, longitude: -79.3449, name: "Saint Germain Bakery", typeOfFood: "Bakery")
    ]
    // mexician restaurants
    let mexicanRestaurants = [
        Restaurant(latitude: 43.6430, longitude: -79.4015, name: "Casa Madera", typeOfFood: "Mexican"),
        Restaurant(latitude: 43.6498, longitude: -79.3973, name: "Seven Lives", typeOfFood: "Mexican"),
        Restaurant(latitude: 43.6445, longitude: -79.3950, name: "Wilbur Mexicana", typeOfFood: "Mexican"),
        Restaurant(latitude: 43.6506, longitude: -79.3590, name: "El Catrin", typeOfFood: "Mexican"),
        Restaurant(latitude: 43.6526, longitude: -79.3794, name: "Rosalinda Restaurant", typeOfFood: "Mexican"),
        Restaurant(latitude: 43.6565, longitude: -79.4070, name: "Quetzal", typeOfFood: "Mexican")
    ]
}

struct ContentView: View {
    @StateObject var model = RestaurantModel()
    @State var cameraPosition = MapCameraPosition.automatic
    @State var selection: Restaurant?
    
    @State private var region = MKCoordinateRegion(
            center: CLLocationCoordinate2D(
                latitude: 43.67,
                longitude: -79.38
            ),
            span: MKCoordinateSpan(
                latitudeDelta: 10,
                longitudeDelta: 10
            )
        )
    var body: some View {
        Map(
            position: $cameraPosition,
            selection: $selection
                    
        ) {
            ForEach(model.bakeries + model.mexicanRestaurants) { restaurant in
                if (restaurant.typeOfFood == "Mexican") {
                    Annotation(restaurant.name, coordinate:restaurant.coordinate) {
                        Text(verbatim: "🇲🇽")
                            .padding(2)
                            .background(Color.black.opacity(0.4), in: Circle())
                            .onTapGesture {
                                selection = restaurant
                                withAnimation(.easeOut(duration: 0.3)) {
                                    cameraPosition = .camera(MapCamera(
                                        centerCoordinate: restaurant.coordinate,distance: 500))}
                            }
                        
                    }
                }
                    
                else {
                    Marker(restaurant.name,
                           systemImage: "birthday.cake",
                           coordinate: restaurant.coordinate)
                    .tag(restaurant) // this will be the value $selection get's set to
                    
                }
                
            }
        }
        .sheet(item: $selection) { restaurant in
                   Text("Restaurant: \(restaurant.name)\nType of Food: \(restaurant.typeOfFood)")
                       .presentationDetents([.fraction(0.25)])
                       .interactiveDismissDisabled(true)
               }
    }
    
    
}

#Preview {
    ContentView()
}
