//
//  MAPD724_Assignment3_Group10App.swift
//  MAPD724_Assignment3_Group10
//
//  Created by Windy on 2025-03-11.
//

import SwiftUI

@main
struct MAPD724_Assignment3_Group10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
